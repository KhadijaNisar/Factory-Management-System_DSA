#include<iostream>
#include<string.h>
#include<stdio.h>
#include<math.h>
#include<fstream>
#include<stdlib.h>
using namespace std;;
//								Factory Management System 
//Class of Node
class Node
{
	private:
		string UserName;
		string Password;
		int EmployeeID;
		int EmployeeWH;
		string EmployeeName;
		string PhoneNo;
		int EmployeeRank;
		string EmployeeCNIC;
		string EmployeeDept;
		Node* next;
	
	public:
		void SetEmployeeID(int);
		void SetEmployeeName(string);
		void SetPhoneNo(string);
		int GetEmployeeID();
		string GetEmployeeName();
		string GetPhoneNo();
		void SetEmployeeRank(int);
		void SetEmployeeWH(int);	
		void SetEmployeeCNIC(string);
		void SetEmployeeDept(string);
		int GetEmployeeRank();
		int GetEmployeeWH();
		string GetEmployeeCNIC();
		string GetEmployeeDept();
		void SetNext(Node*);
		Node* GetNext();
};

//Setters
void Node::SetNext(Node* Next)
{
	this->next=Next;
}
Node* Node::GetNext()
{
	return this->next;
}
void Node::SetEmployeeID(int ID)
{
	EmployeeID=ID;
}
void Node::SetEmployeeName(string Name)
{
	EmployeeName=Name;
}
void Node::SetPhoneNo(string phoneNo)
{
	PhoneNo=phoneNo;
}
void Node::SetEmployeeRank(int Rank)
{
	EmployeeRank=Rank;
}
void Node::SetEmployeeWH(int wh)
{
	EmployeeWH=wh;
}
void Node::SetEmployeeCNIC(string CNIC)
{
	EmployeeCNIC=CNIC;
}
void Node::SetEmployeeDept(string Department)
{
	EmployeeDept=Department;
}

//Getter
int Node::GetEmployeeWH()
{
	return this->EmployeeWH;
}
int Node::GetEmployeeID()
{
	return this->EmployeeID;
}
string Node::GetEmployeeName()
{
	return this->EmployeeName;
}
string Node::GetPhoneNo()
{
	return this->PhoneNo;
}
int Node::GetEmployeeRank()
{
	return this->EmployeeRank;
}
string Node::GetEmployeeCNIC()
{
	return this->EmployeeCNIC;
}
string Node::GetEmployeeDept()
{
	return this->EmployeeDept;
}

//List Class
class SinglyList
{
	private:
		Node* CurrentLocation;
	
	public:
		SinglyList();
		void SetCurrentLocation(Node*);
		bool Registration();
		bool Login();
		void AddEmployee(string,string,int,int,string,string,int);
		void SearchEmployee(int);
		void DeleteEmployee(int);
		void PrintEmployee();
		void Menu();
		void EmployeeMenu();
		void AdminMenu();
		void ManagerMenu();
		void CalculateSal();
		void Attendance();
		void SaveInFile();	
};

void SinglyList::SaveInFile()
{
	
}
void SinglyList::CalculateSal()
{
	
}
void SinglyList::Attendance()
{
	
}
void SinglyList::ManagerMenu()
{
	int choice;
	cout<<"\t\t\t\t_______________________________________________________\n\n";
    cout<<"\t\t\t\t--------------|FACTORY MANAGEMENT SYSTEM|--------------\n";
    cout<<"\t\t\t\t-------------------------------------------------------\n";
    cout<<"\t\t\t\t--------- 1=> VIEW ALL EMPLOYEE------------------------\n";
    cout<<"\t\t\t\t--------- 2=> CALCULATE SALARY-------------------------\n";
    cout<<"\t\t\t\t--------- 3=> SEARCH EMPLOYEE BY ID--------------------\n";
    cout<<"\t\t\t\t--------- 4=> EXIT-------------------------------------\n";
    cout<<"\t\t\t\t_______________________________________________________\n"<<endl;
    cout<<"\t\t\t\t-------------------------------------------------------\n";
    cout<<"CHOOSE THE MENU YOU WANT TO DO : (1,2,3,4) "<<endl;
    cout<<"\t\t\t\t-------------------------------------------------------"<<endl;
	cin>>choice;
	if(choice==1)
	{
		PrintEmployee();
		system("pause");
		system("CLS");
		ManagerMenu();
	}
	else if(choice==2)
	{
		int searchID;
		cout<<"ENTER THE EMPLOYEE ID THAT YOU WANT TO SEARCH : ";
		cin>>searchID;
		SearchEmployee(searchID);
		system("pause");
		system("CLS");
		ManagerMenu();
	}
	else if(choice==3)
	{
		CalculateSal();
		system("pause");
		system("CLS");
		ManagerMenu();
	}
	else if(choice==4)
	{
		Menu();			
	}
	else
	{
		cout<<"Wrong Choice !!!";
		ManagerMenu();					
	}	
}
void SinglyList::AdminMenu()
{
	int choice;
	cout<<"\t\t\t\t_______________________________________________________\n\n";
    cout<<"\t\t\t\t---------|FACTORY - WORKER MANAGEMENT SYSTEM|----------\n";
    cout<<"\t\t\t\t-------------------------------------------------------\n";
    cout<<"\t\t\t\t--------- 1=> ENTER NEW RECORD-------------------------\n";
    cout<<"\t\t\t\t--------- 2=> DISPLAY ALL RECORD-----------------------\n";
    cout<<"\t\t\t\t--------- 3=> SEARCH EMPLOYEE BY ID--------------------\n";
    cout<<"\t\t\t\t--------- 4=> ATTENDENCE OF EMPLOYEE-------------------\n";
    cout<<"\t\t\t\t--------- 5=> SAVE RECORD IN FILE----------------------\n";
    cout<<"\t\t\t\t--------- 6=> DELETE EMPLOYEE--------------------------\n";
    cout<<"\t\t\t\t--------- 7=> EXIT-------------------------------------\n";
    cout<<"\t\t\t\t_______________________________________________________\n"<<endl;
    cout<<"\t\t\t\t-------------------------------------------------------\n";
    cout<<"CHOOSE THE MENU YOU WANT TO DO : (1,2,3,4,5,6,7) "<<endl;
    cout<<"\t\t\t\t-------------------------------------------------------"<<endl;
	cin>>choice;
	if(choice==1)
	{
		int Emp_ID,emp_rank,emp_WH;
		string emp_Name,emp_phone,emp_CNIC,emp_dept;
		cout<<"ENTER PHONE NUMBER OF THE WORKER --> ";
		cin>>emp_phone;
		cout<<"ENTER NAME OF THE WORKER --> ";
		cin.ignore();
		getline(cin,emp_Name);
		cout<<"ENTER CNIC OF THE WORKER --> ";
		getline(cin,emp_CNIC);
		cout<<"ENTER DEPERTMENT OF THE WORKER --> ";
		getline(cin, emp_dept);
		cout<<"ENTER ID OF THE WORKER --> ";
	//	checkno(emp_CNIC,16);
		cin>>Emp_ID;
		cout<<"ENTER RANK OF THE WORKER --> ";
		cin>>emp_rank; 
		cout<<"ENTER WH OF THE WORKER --> ";
		cin>>emp_WH;     	
		AddEmployee(emp_Name,emp_phone,Emp_ID,emp_rank,emp_CNIC,emp_dept,emp_WH);
		system("pause");
		system("CLS");
		AdminMenu();
	}
	else if(choice==2)
	{
		int searchID;
		cout<<"Enter the Employee_ID that you want to Search : ";
		cin>>searchID;
		SearchEmployee(searchID);
		system("pause");
		system("CLS");
		AdminMenu();
	}
	else if(choice==3)
	{
		int deleteID;
		cout<<"Enter the Employee_ID that you want to delete : ";
		cin>>deleteID;
		DeleteEmployee(deleteID);
		system("pause");
		system("CLS");
		AdminMenu();
				}
	else if(choice==4)
	{
		PrintEmployee();
		system("pause");
		system("CLS");
		AdminMenu();
	}
	else if(choice==5)
	{
		Attendance();
		system("pause");
		system("CLS");
		AdminMenu();				
	}
	else if(choice==6)
	{
		SaveInFile();
		system("pause");
		system("CLS");
		AdminMenu();				
	}
	else if(choice==7)
	{
		system("pause");
		system("CLS");
		AdminMenu();				
	}
	else
	{
		cout<<"Wrong Choice !!!";					
		system("pause");
		system("CLS");
		AdminMenu();
	}	
}
void SinglyList::EmployeeMenu()
{
	int choice;
	int Emp_ID,emp_rank,emp_WH;
	string emp_Name,emp_phone,emp_CNIC,emp_dept;
	cout<<"\t\t\t\t_______________________________________________________\n\n";
    cout<<"\t\t\t\t--------------|FACTORY MANAGEMENT SYSTEM|--------------\n";
    cout<<"\t\t\t\t-------------------------------------------------------\n";
    cout<<"\t\t\t\t--------- 1=> ADD EMPLOYEE-----------------------------\n";
    cout<<"\t\t\t\t--------- 2=> SAVE IN FILE-----------------------------\n";
    cout<<"\t\t\t\t--------- 3=> VIEW YOUR DETAILS BY ID------------------\n";
    cout<<"\t\t\t\t--------- 4=> EXIT-------------------------------------\n";
    cout<<"\t\t\t\t_______________________________________________________\n"<<endl;
    cout<<"\t\t\t\t-------------------------------------------------------\n";
    cout<<"CHOOSE THE MENU YOU WANT TO DO : (1,2,3,4) "<<endl;
    cout<<"\t\t\t\t-------------------------------------------------------"<<endl;
	cin>>choice;
	if(choice==1)
	{
		cout<<"ENTER PHONE NUMBER OF THE WORKER --> ";
		cin>>emp_phone;
		cout<<"ENTER NAME OF THE WORKER --> ";
		cin.ignore();
		getline(cin,emp_Name);
		cout<<"ENTER CNIC OF THE WORKER --> ";
		getline(cin,emp_CNIC);
		cout<<"ENTER DEPERTMENT OF THE WORKER --> ";
		getline(cin, emp_dept);
		cout<<"ENTER ID OF THE WORKER --> ";
	//	checkno(emp_CNIC,16);
		cin>>Emp_ID;
		cout<<"ENTER RANK OF THE WORKER --> ";
		cin>>emp_rank;  
		cout<<"ENTER WORKING HOURS OF THE WORKER --> ";
		cin>>emp_WH;  	
		AddEmployee(emp_Name,emp_phone,Emp_ID,emp_rank,emp_CNIC,emp_dept,emp_WH);
		system("pause");
		system("CLS");
		EmployeeMenu();
	}
	else if(choice==2)
	{
		int searchID;
		cout<<"Enter the Employee_ID that you want to Search : ";
		cin>>searchID;
		SearchEmployee(searchID);
		system("pause");
		system("CLS");
		EmployeeMenu();
	}
	else if(choice==3)
	{
		system("pause");
		system("CLS");
		Menu();
	}
	else if(choice==4)
	{
		SaveInFile();				
		system("pause");
		system("CLS");
		EmployeeMenu();
	}	
	else
	{
		cout<<"Wrong Choice !!!";					
		system("pause");
		system("CLS");
		EmployeeMenu();
	}	
}
void SinglyList::Menu()
{
	int option=1;
	int choice;
	int end=0;
	cout<<"\t\t\t\t_______________________________________________________\n\n";
    cout<<"\t\t\t\t--------------|FACTORY MANAGEMENT SYSTEM|--------------\n";
    cout<<"\t\t\t\t-------------------------------------------------------\n";
	while(option!=0)
	{
   		cout<<"\t\t\t\t--------- 1=> REGISTRATION IN FMS----------------------\n";
    	cout<<"\t\t\t\t--------- 2=> LOGIN FMS--------------------------------\n";
   	 	cout<<"\t\t\t\t--------- 3=> EXIT-------------------------------------\n";
  	  	cout<<"\t\t\t\t_______________________________________________________\n"<<endl;
	    cout<<"\t\t\t\t-------------------------------------------------------\n";
    	cout<<"CHOOSE THE MENU YOU WANT TO DO : (1,2,3) "<<endl;
  	  	cout<<"\t\t\t\t-------------------------------------------------------"<<endl;
		cin>>option;
		if(option==1)
		{
			system("pause");
			system("CLS");
			Registration();
		}
		else if(option==2)
		{
			system("pause");
			system("CLS");
			Login();
		}
		else if(option==0)
		{
			system("pause");
			system("CLS");
			return;
		}
		else
		{
			system("pause");
			system("CLS");
			cout<<"\nWrong Choice !!!"<<endl;
			return;
		}
	}	
	system("pause");
	system("CLS");
		
}
bool SinglyList::Registration()
{
	int choice;
	string userName,password,person;
	cout<<"\t\t\t\t_______________________________________________________\n\n";
    cout<<"\t\t\t\t--------------|FACTORY MANAGEMENT SYSTEM|--------------\n";
    cout<<"\t\t\t\t-------------------------------------------------------\n";
    cout<<"\t\t\t\t------------------- *REGISTARTION* --------------------\n"; 
    cout<<"\t\t\t\t--------- 1=> REGISTER AS MANAGER----------------------\n";
    cout<<"\t\t\t\t--------- 2=> REGISTER AS EMPLOYEE---------------------\n";
    cout<<"\t\t\t\t--------- 3=> REGISTER AS ADMIN------------------------\n";
    cout<<"\t\t\t\t--------- 4=> EXIT-------------------------------------\n";
    cout<<"\t\t\t\t_______________________________________________________\n"<<endl;
    cout<<"\t\t\t\t-------------------------------------------------------\n";
    cout<<"CHOOSE THE MENU YOU WANT TO DO : (1,2,3,4) "<<endl;
    cout<<"\t\t\t\t-------------------------------------------------------"<<endl;
	cin>>choice;
	if(choice==1)
	{
		string userName,password;
		ofstream ManagerloginFile;
		ManagerloginFile.open("ManagerLoginFile",ios::app);
		cout<<"\n\n\t\t\t\tUserName :- ";
		cin>>userName;
		cout<<"\n\n\t\t\t\tPassword :-";
		cin>>password;
		if(!ManagerloginFile.is_open())
		{
    		cout<<"\aThe file could not open !";
        	Menu();
   		}
		ManagerloginFile<<userName<<" "<<password<<endl;
		ManagerloginFile.close();
		system("cls");
		cout<<"Registration as a Manager is Successfull !!!";
		ManagerMenu();
	}
	else if(choice==2)
	{
		string userName,password;
		ofstream EmployeeloginFile;
		EmployeeloginFile.open("EmployeeLoginFile",ios::app);
		cout<<"\n\n\t\t\t\tUserName :- ";
		cin>>userName;
		cout<<"\n\n\t\t\t\tPassword :-";
		cin>>password;
		if(!EmployeeloginFile.is_open())
		{
    		cout<<"\aThe file could not open !";
        	Menu();
   		}
		EmployeeloginFile<<userName<<" "<<password<<endl;
		EmployeeloginFile.close();
		system("cls");
		cout<<"Registration as a Employee is Successfull !!!";
		EmployeeMenu();
		
	}		
	else if(choice==3)
	{
		string userName,password;
		ofstream AdminloginFile;
		AdminloginFile.open("AdminLoginFile",ios::app);
		cout<<"\n\n\t\t\t\tUserName :- ";
		cin>>userName;
		cout<<"\n\n\t\t\t\tPassword :-";
		cin>>password;
		if(!AdminloginFile.is_open())
		{
    		cout<<"\aThe file could not open !";
        	Menu();
   		}
		AdminloginFile<<userName<<" "<<password<<endl;
		AdminloginFile.close();
		system("cls");
		cout<<"Registration is Admin is  Successfull !!!";
		AdminMenu();
	}
	else if(choice==4)
	{
		Menu();
	}
	else
	{
		cout<<"Wrong Input !!!"<<endl;
		Menu();
	}
}

SinglyList::SinglyList()
{
	CurrentLocation=NULL;
}
void SinglyList::SetCurrentLocation(Node* head)
{
	this->CurrentLocation=head;
}

bool SinglyList::Login()
{
	int choice;
	cout<<"\t\t\t\t_______________________________________________________\n\n";
    cout<<"\t\t\t\t--------------|FACTORY MANAGEMENT SYSTEM|--------------\n";
    cout<<"\t\t\t\t-------------------------------------------------------\n";
    cout<<"\t\t\t\t-------------------- *LOGIN* --------------------------\n"; 
    cout<<"\t\t\t\t--------- 1=> LOGIN AS MANAGER-------------------------\n";
    cout<<"\t\t\t\t--------- 2=> LOGIN AS EMPLOYEE------------------------\n";
    cout<<"\t\t\t\t--------- 3=> LOGIN AS ADMIN---------------------------\n";
    cout<<"\t\t\t\t--------- 4=> EXIT-------------------------------------\n";
    cout<<"\t\t\t\t_______________________________________________________\n"<<endl;
    cout<<"\t\t\t\t-------------------------------------------------------\n";
    cout<<"CHOOSE THE MENU YOU WANT TO DO : (1,2,3,4) "<<endl;
    cout<<"\t\t\t\t-------------------------------------------------------"<<endl;
		cin>>choice;
		if(choice==1)
		{
			int exist;
			string userName,password,fuserName,fpassword;
			cout<<"\n\n\t\t\t\tUserName :- ";
			cin>>userName;
			cout<<"\n\n\t\t\t\tPassword :-";
			cin>>password;
			ifstream AdminloginFile;
			AdminloginFile.open("AdminLoginFile");
			if(!AdminloginFile.is_open())
			{
    			cout<<"\aThe file could not open !";
        		Menu();
   			}
   			while(AdminloginFile>>fuserName>>fpassword)
   			{
   				if(userName==fuserName && password==fpassword)
   				{
   					exist=1;
				}
			}
			AdminloginFile.close();
			if(exist==1)
			{
				cout<<"Login as Admin was Successfull !!!"<<endl;
				AdminMenu();	
			}
			else
			{
				string forget;
				cout<<"Login was Unsuccessfull !!!"<<endl;
				cout<<"Did you forget your Password yes/no?"<<endl;
				cin>>forget;
				if(forget=="yes")
				{
					int exist=0;
					string userName,sU,sP;
					cout<<"\nEnter your userName :";
					cin>>userName;
					ifstream AdminloginFile;
					AdminloginFile.open("AdminLoginFile");
					while(AdminloginFile>>sU>>sP)
					{
						if(sU==userName)
						{
							exist=1;
							break;
						}
					}
					AdminloginFile.close();
					if(exist==1)
					{
						cout<<"Your account was found !!"<<endl;
						cout<<"Your Password is : "<<sP;
						cin.get();
					}
					else
					{
						cout<<"Sorry your account is not found !!!"<<endl;
						Menu();
					}
				}
				else
				{
					Menu();
				}
				
			}
			}

		else if(choice==2)
		{
			int exist;
			string userName,password,fuserName,fpassword;
			cout<<"\n\n\t\t\t\tUserName :- ";
			cin>>userName;
			cout<<"\n\n\t\t\t\tPassword :-";
			cin>>password;
			ifstream ManagerloginFile;
			ManagerloginFile.open("ManagerLoginFile");
			if(!ManagerloginFile.is_open())
			{
    			cout<<"\aThe file could not open !";
        		Menu();
   			}
   			while(ManagerloginFile>>fuserName>>fpassword)
   			{
   				if(userName==fuserName && password==fpassword)
   				{
   					exist=1;
				}
			}
			ManagerloginFile.close();
			if(exist==1)
			{
				cout<<"Login as Manager was Successfull !!!"<<endl;	
				ManagerMenu();
			}
			else
			{
				string forget;
				cout<<"Login was Unsuccessfull !!!"<<endl;
				cout<<"Did you forget your Password yes/no?"<<endl;
				cin>>forget;
				if(forget=="yes")
				{
					int exist=0;
					string userName,sU,sP;
					cout<<"\nEnter your userName :";
					cin>>userName;
					ifstream ManagerloginFile;
					ManagerloginFile.open("ManagerLoginFile");
					while(ManagerloginFile>>sU>>sP)
					{
						if(sU==userName)
						{
							exist=1;
							break;
						}
					}
					ManagerloginFile.close();
					if(exist==1)
					{
						cout<<"Your account was found !!"<<endl;
						cout<<"Your Password is : "<<sP;
						cin.get();
					}
					else
					{
						cout<<"Sorry your account is not found !!!"<<endl;
						Menu();
					}
				}
				else
				{
					Menu();
				}
				
			}
		}
		else if(choice==3)
		{
			int exist;
			string userName,password,fuserName,fpassword;
			cout<<"\n\n\t\t\t\tUserName :- ";
			cin>>userName;
			cout<<"\n\n\t\t\t\tPassword :-";
			cin>>password;
			ifstream EmployeeloginFile;
			EmployeeloginFile.open("AdminLoginFile");
			if(!EmployeeloginFile.is_open())
			{
    			cout<<"\aThe file could not open !";
        		Menu();
   			}
   			while(EmployeeloginFile>>fuserName>>fpassword)
   			{
   				if(userName==fuserName && password==fpassword)
   				{
   					exist=1;
				}
			}
			EmployeeloginFile.close();
			if(exist==1)
			{
				cout<<"Login as Employee was Successfull !!!"<<endl;
				EmployeeMenu();	
			}
			else
			{
				string forget;
				cout<<"Login was Unsuccessfull !!!"<<endl;
				cout<<"Did you forget your Password yes/no?"<<endl;
				cin>>forget;
				if(forget=="yes")
				{
					int exist=0;
					string userName,sU,sP;
					cout<<"\nEnter your userName :";
					cin>>userName;
					ifstream EmployeeloginFile;
					EmployeeloginFile.open("EmployeeLoginFile");
					while(EmployeeloginFile>>sU>>sP)
					{
						if(sU==userName)
						{
							exist=1;
							break;
						}
					}
					EmployeeloginFile.close();
					if(exist==1)
					{
						cout<<"Your account was found !!"<<endl;
						cout<<"Your Password is : "<<sP;
						cin.get();
					}
					else
					{
						cout<<"Sorry your account is not found !!!"<<endl;
						Menu();
					}
				}
			}
		}
		
		else if(choice==4)
		{
			Menu();
		}
		else
		{
			cout<<"Wrong Input !!!"<<endl;
			Menu();
		}
	
}
//Add Employee
void SinglyList::AddEmployee(string name,string phone,int ID,int rank,string cnic,string dept,int wh)
{
	Node* tempNode=CurrentLocation;
	Node* newNode=new Node();
	newNode->SetEmployeeName(name);
	newNode->SetPhoneNo(phone);
	newNode->SetEmployeeWH(wh);	
	newNode->SetEmployeeID(ID);
	newNode->SetEmployeeRank(rank);
	newNode->SetEmployeeCNIC(cnic);
	newNode->SetEmployeeDept(dept);	
	newNode->SetNext(NULL);
	if(tempNode==NULL)
	{
		CurrentLocation=newNode;
		return;
	}
	if(tempNode->GetNext()==NULL)
	{
		if(tempNode->GetEmployeeID()==ID)
		{
			cout<<"This ID Already Exists !!!";
			return;
		}
		tempNode->SetNext(newNode);
	}
	else
	{
		while(tempNode->GetNext()!=NULL)
		{
			if(tempNode->GetEmployeeID()==ID)
			{
				cout<<"This ID Already Exists !!!";
				return;
			}
			tempNode=tempNode->GetNext();
		}
		tempNode->SetNext(newNode);
	}
}
//Print Employee
void SinglyList::PrintEmployee()
{
	Node* tempNode=CurrentLocation;
	if(tempNode==NULL)
	{
		cout<<"No Employee Is Registered !!!"<<endl;
		return;
	}
	else if(tempNode->GetNext()==NULL)
	{
		cout<<"\t____________________________________________________________________________________________________\n";
	    cout<<"\t|\tNAME                |\t"<<tempNode->GetEmployeeName()<<endl;
	    cout<<"\t----------------------------------------------------------------------------------------------------\n";
		cout<<"\t|\tDEPARTMENT		    |\t"<<tempNode->GetEmployeeDept()<<endl;
	    cout<<"\t----------------------------------------------------------------------------------------------------\n";
		cout<<"\t|\tPHONE NUMBER        |\t"<<tempNode->GetPhoneNo()<<endl;
		cout<<"\t----------------------------------------------------------------------------------------------------\n";
		cout<<"\t|\tWORKING HOURS		|\t"<<tempNode->GetEmployeeWH()<<endl;
	    cout<<"\t----------------------------------------------------------------------------------------------------\n";
	    cout<<"\t|\tCNIC                |\t"<<tempNode->GetEmployeeCNIC()<<endl;
	    cout<<"\t----------------------------------------------------------------------------------------------------\n";       
		cout<<"\t|\tID          		|\t"<<tempNode->GetEmployeeID()<<endl; 	
		cout<<"\t----------------------------------------------------------------------------------------------------\n";       
		cout<<"\t|\tRANK         		|\t"<<tempNode->GetEmployeeRank()<<endl;
		cout<<"\t____________________________________________________________________________________________________\n\n";  
	}
	else
	{
		while(tempNode!=NULL)
		{
			cout<<"\t____________________________________________________________________________________________________\n";
	        cout<<"\t|\tNAME                |\t"<<tempNode->GetEmployeeName()<<endl;
	        cout<<"\t----------------------------------------------------------------------------------------------------\n";
			cout<<"\t|\tDEPARTMENT		    |\t"<<tempNode->GetEmployeeDept()<<endl;
	        cout<<"\t----------------------------------------------------------------------------------------------------\n";
			cout<<"\t|\tWORKING HOURS		|\t"<<tempNode->GetEmployeeWH()<<endl;			
	    	cout<<"\t----------------------------------------------------------------------------------------------------\n";
			cout<<"\t|\tPHONE NUMBER        |\t"<<tempNode->GetPhoneNo()<<endl;
	        cout<<"\t----------------------------------------------------------------------------------------------------\n";
	        cout<<"\t|\tCNIC                |\t"<<tempNode->GetEmployeeCNIC()<<endl;
	        cout<<"\t----------------------------------------------------------------------------------------------------\n";       
			cout<<"\t|\tID          		|\t"<<tempNode->GetEmployeeID()<<endl; 	
			cout<<"\t----------------------------------------------------------------------------------------------------\n";       
			cout<<"\t|\tRANK         		|\t"<<tempNode->GetEmployeeRank()<<endl;
			cout<<"\t____________________________________________________________________________________________________\n\n";  
			tempNode=tempNode->GetNext();
			cout<<endl;
		}
	}
}
// Search Employee
void SinglyList::SearchEmployee(int searchID)
{
	int search=0;
	Node* tempNode=CurrentLocation;
	if(tempNode==NULL)
	{
		cout<<"There is no record to search !!!";
		return;
	}
	else
	{
		while(tempNode!=NULL)
		{
			if(tempNode->GetEmployeeID()==searchID)
			{
				search++;
			}
			tempNode=tempNode->GetNext();
		}
	}
	if(search>0)
	{
		cout<<"Record Found !!!"<<endl;
	}
	else
	{
		cout<<"Record Not Found !!!"<<endl;
	}
	
}
//Delete Employee
void SinglyList::DeleteEmployee(int deleteID)
{
	int exist=0;
	Node* tempNode=CurrentLocation;
	Node* previous=new Node();
	//IF First Node
	if(tempNode->GetEmployeeID()==deleteID)
	{
		CurrentLocation=tempNode->GetNext();
		delete tempNode;
		exist++;
		tempNode=NULL;
	}
	//If Last Node
	else  if(tempNode->GetNext()==NULL)
	{
		delete tempNode;
		exist++;
		tempNode=NULL;
	}
	//If any other node
	else
	{
		while(tempNode!=NULL)
		{
			if(tempNode->GetEmployeeID()==deleteID)
			{
				return;
				exist++;
			}
			previous=tempNode;
			tempNode->GetNext();
		}
		previous->SetNext(tempNode->GetNext());
		delete tempNode;
		tempNode=NULL;
	}
	if(exist>0)
	{
		cout<<"Record Deleted Successfully !!!"<<endl;
	}
	else
	{
		cout<<"Record Not Found !!!"<<endl;
	}
}
int main()
{
	SinglyList l;
	Node* n=new Node();
	l.Menu();
	return 0;
}